const express = require('express');
const path = require('path');
const mysql = require('mysql');
const dotenv = require('dotenv');

const jwt = require('jsonwebtoken');

const cookieParser = require('cookie-parser');
const { requireAuth } = require('./middleware/middlewareAuth');

dotenv.config( { path: './.env' } )

const app = express();

const db = mysql.createConnection({
  host: process.env.DATABASE_HOST,
  user: process.env.DATABASE_USER,
  password: process.env.DATABASE_PASSWORD,
  database: process.env.DATABASE

});

const publicDirectory = path.join(__dirname, './public');
app.use(express.static(publicDirectory));

app.use(express.urlencoded({extended: false}));
app.use(express.json());
app.use(cookieParser());

app.set('viewengine', 'hbs');

db.connect((error) =>{
  if(error){
    console.log('error connecting: ' + error);
    
  }else{
    console.log("Database connected..");
  }
});

app.get('/login', (req,res) => res.render('login.hbs'))
app.get('/register', (req,res) => res.render('register.hbs'))

app.get('/', requireAuth,(req,res) => res.render('index.hbs'))
app.get('/hospital_add', requireAuth,(req,res) => res.render('hospital_add.hbs'))
app.get('/categories_add', requireAuth,(req,res) => res.render('categories_add.hbs'))
app.get('/doctor_add', requireAuth,(req,res) => res.render('doctor_add.hbs'))



/*===================================================================
          HOSPITAL SECTION
===================================================================== */
  app.get('/hospital', requireAuth,function(req,res){
    db.query('SELECT * FROM hospital_name', function(err, row) {
      if(err){
          console.log(err)
      }
      else{
        //console.log(row)
        res.render('hospital.hbs', {title: "Hospital Name", hos:row})
          
      }
  })
  });

  app.get('/edit-hospital-form/:H_id', function(req, res, next) {
    var H_id = req.params.H_id;
    //var sql = `SELECT * FROM hospital_name WHERE H_id=${H_id}`;
    db.query(`SELECT * FROM hospital_name WHERE H_id=${H_id}`, function(err, row) {
        console.log(row[0]);
        res.render('editHospital.hbs', {hos: row[0]});
    });
  });


  app.post('/edit/:H_id', function(req, res, next) {
    var hname = req.body.hname;
    var hlocation = req.body.hlocation;
    var H_id = req.params.H_id;
    
    //var sql = `UPDATE hospital_name SET hname="${hname}", hlocation="${hlocation}" WHERE H_id=${H_id}`;
  
    db.query(`UPDATE hospital_name SET hname="${hname}", hlocation="${hlocation}" WHERE H_id=${H_id}`, function(err, row) {
      // if (err) throw err;
      // console.log('record updated!');
      // res.redirect('/hospital.hbs');
      if(err){
        console.log(err)
    }
    else{
      //console.log(row)
      res.redirect('/hospital')
        
    }
    });
  });

  app.get('/delete-hospital/:H_id', function(req, res){
    var H_id = req.params.H_id;
    console.log(H_id);
    var sql = `DELETE FROM hospital_name WHERE H_id=${H_id}`;
  
    db.query(sql, function(err, result) {
      if (err) throw err;
      console.log('record deleted!');
      res.redirect('/hospital');
    });
  });



  /*=======================================================================================
      SPECIALIST SECTION
  ========================================================================================*/
  app.get('/categories', requireAuth,function(req,res){
    db.query('SELECT * FROM specialist', function(err, row) {
      if(err){
          console.log(err)
      }
      else{
        console.log(row)
        res.render('categories.hbs', {spc:row})
          
      }
  })
  });



  app.get('/edit-categories-form/:S_id', function(req, res, next) {
    var S_id = req.params.S_id;

    db.query(`SELECT * FROM specialist WHERE S_id=${S_id}`, function(err, row) {
        console.log(row[0]);
        res.render('editCategories.hbs', {spc: row[0]});
    });
  });


  app.post('/edit-s/:S_id', function(req, res, next) {
    var name = req.body.name;
    var h_id = req.body.h_id;
    var S_id = req.params.S_id;
    
    //var sql = `UPDATE hospital_name SET hname="${hname}", hlocation="${hlocation}" WHERE H_id=${H_id}`;
  
    db.query(`UPDATE specialist SET name="${name}", h_id="${h_id}" WHERE S_id=${S_id}`, function(err, row) {
      
      if(err){
        console.log(err)
    }
    else{
      //console.log(row)
      res.redirect('/categories')
        
    }
    });
  });

 

  app.get('/delete-categories/:S_id', function(req, res){
    var S_id = req.params.S_id;
    console.log(S_id);
    var sql = `DELETE FROM specialist WHERE S_id=${S_id}`;
  
    db.query(sql, function(err, result) {
      if (err) throw err;
      console.log('record deleted!');
      res.redirect('/categories');
    });
  });
  

  



  /*===================================================================
          DOCTOR SECTION
===================================================================== */
app.get('/doctor', requireAuth,function(req,res){
  db.query('SELECT * FROM doctor', function(err, row) {
    if(err){
        console.log(err)
    }
    else{
      //console.log(row)
      res.render('doctor.hbs', {dr:row})
        
    }
})
});


app.get('/edit-doctor-form/:D_id', function(req, res, next) {
  var D_id = req.params.D_id;

  db.query(`SELECT * FROM doctor WHERE D_id=${D_id}`, function(err, row) {
      console.log(row[0]);
      res.render('editDoctor.hbs', { dr: row[0]});
  });
});


app.post('/edit-d/:D_id', function(req, res, next) {
  var name = req.body.name;
  var dlocation = req.body.dlocation;
  var H_id = req.body.H_id;
  var contact_no = req.body.contact_no;
  var qualification = req.body.qualification;
  var S_id = req.body.S_id;

  var D_id = req.params.D_id;
  

  db.query(`UPDATE doctor SET name="${name}",dlocation="${dlocation}" , H_id="${H_id}", contact_no="${contact_no}", qualification="${qualification}", S_id="${S_id}" WHERE D_id=${D_id}`, function(err, row) {
    
    if(err){
      console.log(err)
  }
  else{
    console.log(row)
    res.redirect('/doctor')
      
  }
  });
});

app.get('/delete-doctor/:D_id', function(req, res){
  var D_id = req.params.D_id;
  //console.log(S_id);
  var sql = `DELETE FROM doctor WHERE D_id=${D_id}`;

  db.query(sql, function(err, result) {
    if (err) throw err;
    console.log('record deleted!');
    res.redirect('/doctor');
  });
});




//app.use('/', ('./routes/pages.js'))
app.use('/auth', require('./routes/auth'))






/* ======================================================
   PASS & SHOW DATA IN FRONT END PART
=======================================================*/

const cors = require('cors');
const { categories } = require('./controllers/auth');
app.use(cors());
app.use(express.json());


app.get("/HospitalName", (req, res) => {
  db.query("SELECT * FROM hospital_name", (err, result) => {
    if (err) {
      console.log(err);
    } else {
      console.log('hi')
      res.send(result);
    }
  });
});









app.listen(3001,()=> console.log("listening port 3001"));